<?php
/**
 * Deprecated functions
 * @package WordPress
 * @subpackage GoPress WPExplorer Theme
 * @since GoPress 1.0
 */

function wpex_get_featured_img_url() {
	_deprecated_function( 'wpex_get_featured_img_url', '2.0.0', 'the_post_thumbnail' );
}