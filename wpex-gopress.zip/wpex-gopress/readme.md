# GoPress Free WordPress theme

A free WordPress theme by WPExplorer. Learn more here: http://www.wpexplorer.com/gopress-wordpress-theme/